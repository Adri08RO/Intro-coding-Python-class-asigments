#Para el laboratorio 7
print("\nLaboratorio 7")
#Los metodos que vamos a utilizar son 4 y lo primero que haremos sera definirlos:

#Metodo de igualdad total de lados por medio del cual se comprueba si todos los lados del triangulo son iguales on lo que mas adelante se ve se usa para definir al triangulo equilatero

def igualdad_de_lados_totales(primer_lado,segundo_lado, tercer_lado):
 igualdad_de_lados_totales = primer_lado==segundo_lado and segundo_lado==tercer_lado and primer_lado==tercer_lado
 return igualdad_de_lados_totales

#Metodo de igualdad de lados con este metodo se verifica si 2 de los lados ingresados del triangulo son iguales que con lo que mas adelante se ve se usa para definir al triangulo como un triangulo isoceles 
def igualdad_de_lados(primer_lado, segundo_lado, tercer_lado):
 igualdad_de_lados= primer_lado==segundo_lado or segundo_lado==tercer_lado or primer_lado==tercer_lado
 return igualdad_de_lados

#Metodo de desigualdad de lados con este metodo se verifica si todos los lados ingresados del triangulo son desiguales que con lo que mas adelante se ve se usa para definir al triangulo como un triangulo escaleno
def desigualdad_de_lados(primer_lado, segundo_lado, tercer_lado):
 desigualdad_de_lados = primer_lado!=segundo_lado and segundo_lado!=tercer_lado and primer_lado!=tercer_lado
 return desigualdad_de_lados

#Metodo de calcular potencia media por medio de este metodo y con la ayuda de los valores de base y exponente se puede sacar el exponente de una base
def Calcular_potencia(base, exponente):
 return base**exponente


#Programa principal

Terminar_programa = False

while Terminar_programa == False:
 #primero se desplega el menu principal
  print("\nMenú de opciones: \n \n 1 - Clasificar un triángulo en equilátero, isósceles o escaleno. \n \n 2 - Calcular una potencia.\n \n 3 - Salir" )
  #Usamos un try-except para que solo se puedan ingresar numeros enteros a la opcion de menu

  # valor_op1 es el valor de la opcion seleccionada del menu de opciones
  valor_op1= int(input("\nIndique la opción seleccionada: "))

  if valor_op1!=1 or valor_op1!=2 or valor_op1 !=3:
   #si se utiliza un numero que no sea 1, 2 o 3 se repite el programa
   print("\nSolo se permiten los valores 1, 2 ó 3 ")
   Terminar_programa= False
  
  if valor_op1 ==1 or valor_op1 ==2 or valor_op1==3:
   #Usamos un if para que en caso que se ingrese 1 se siga el programa de clasificación de triangulo
   if valor_op1==1:
     #Usamos numeros validos como una variable booleana y un while para que cada vez que se ingresen numeros no permitidos como valores de los lados del triangulo con un try-except se indique el error y seguidamente se vuelvan a pedir los valores de los lados del triangulo a clasificar
     numeros_validos=False 
   
     while numeros_validos==False:

       print("\nCLASIFICAR TRIÁNGULO")

       try:
         primer_lado= float(input("\nIngrese la longitud del primer lado: "))
     
         segundo_lado= float(input("\nIngrese la longitud del segundo lado: "))
  
         tercer_lado= float(input("\nIngrese la longitud del tercer lado: "))
       except ValueError:
         print("\nEl valor ingresado no es correcto")
       else:
         numeros_validos = True
    
       # Se usan las opciones if y elif ademas del llamado de metodos definidos previamente para verificar a que tipo de triangulo pertenecen los valores ingresados

       if igualdad_de_lados_totales(primer_lado,segundo_lado, tercer_lado):
         #Si se cumple este es un triangulo equilatero
         print("\nLos lados ingresados corresponde a un triangulo equilatero") 
         Terminar_programa = False
       elif igualdad_de_lados(primer_lado,segundo_lado,tercer_lado):
         #Si se cumple este es un triangulo isoceles
         print("\nLos lados ingresados corresponde a un triangulo isóceles") 
         Terminar_programa = False
       elif desigualdad_de_lados(primer_lado,segundo_lado,tercer_lado):
         #Si se cumple este es un triangulo escaleno
         print("\nLos lados ingresados corresponde a un triangulo escaleno")
         Terminar_programa = False

      

   if valor_op1==2:
     #Para el segundo programa se pide la base y el exponente como dos variables se llama el metodo calcular potencia para calcular la potencia de la base 
     base= int(input("\nDigite el valor de la base: "))
     exponente= int(input("\nDigite el valor del exponente: "))
     Calcular_potencia(base,exponente)
     print("\nEl resultado del calculo es", Calcular_potencia(base,exponente))
     Terminar_programa = False

 
   if valor_op1==3:
     #si la opcion 3 se ejcuta se cierra el programa
     print("\nGracias por utilizar el programa")
     Terminar_programa = True

 
   


   
 
