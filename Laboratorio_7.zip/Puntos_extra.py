print("Puntos extra")
#Ejercicio de puntos extra
#primero se piden las variables de base y de exponente
base= int(input("\nDigite el valor de la base: "))
exponente= int(input("\nDigite el valor del exponente: "))
#Luego se define el metodo para calcular potencia con un for usando resultado como el lugar donde se va a guardar el resultado del recorrido de la multiplicacion de la base las veces del exponente
def calcular_potencia(base,exponente): 
 resultado = 1
 for recorrido in range(exponente):
   resultado = resultado * base
 return resultado
#Se imprime el resultado
print("\nEl resultado del calculo es",calcular_potencia(base,exponente))