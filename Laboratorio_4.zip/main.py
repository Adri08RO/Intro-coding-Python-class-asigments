#Problema 1
print("\nProblema 1")
print("\nBienvenido")

print("\nCon este programa se puede verificar si 3 valores corresponden a una terna pitag\u00F3rica \n")

valor_11=float(input("\nDigite el n\u00FAmero del primer valor: "))
valor_22=float(input("\nDigite el n\u00FAmero del segundo valor: "))
valor_33=float(input("\nDigite el n\u00FAmero del tercer valor: "))

Hipotenusa= 0
cateto_1=0
cateto_2=0
cateto_3=0

if valor_11> valor_22 and valor_11> valor_33:
 Hipotenusa = Hipotenusa + valor_11
else:
  cateto_1 = valor_11+cateto_1
if valor_22>valor_11 and valor_22>valor_33:
   Hipotenusa = valor_22+Hipotenusa 
else:
   cateto_2 = valor_22+cateto_2
if valor_33>valor_22 and valor_33>valor_11:
   Hipotenusa = valor_33+Hipotenusa
else:
     cateto_3= valor_33+cateto_3

print("\n¿El conjunto es una terna pitagorica?")

if ((cateto_1)**2 + (cateto_2)**2 +(cateto_3)**2) == (Hipotenusa)**2:
  print("\ntrue") 
else:
  print("\nfalse")

#Problema 2
print("\nProblema 2")
#Se espicifica la funcion del programa
print("\nCon este programa se puede verificar de entre 3 numeros enteros cual es el mayor, el menor y si hay algun numero repetido")

#se pone el ingreso de variables de los numeros solicitados y se pone un try para evitar que se utilicen numeros que no son enteros
try:
 primer_numero=int(input("\nDigite el n\u00FAmero del primer valor: "))
 segundo_numero=int(input("\nDigite el n\u00FAmero del segundo valor: "))
 tercer_numero=int(input("\nDigite el n\u00FAmero del tercer valor: "))
except ValueError:
  print("El numero ingresado no es entero")

#Se definen los nombres de las constantes que se utilizaran para la operacion de division entera y para determinar si un numero se repite
numero_mayor=0
numero_menor=0
repetido_primer_y_segundo= True
repetido_segundo_y_tercero = True
repetido_tercer_y_primer= True

#Se hace la prueba con las constantes (if y else) para ver si hay algun numero repetido en los valores ingresados
if primer_numero == segundo_numero:
  repetido_primer_y_segundo= True 
else: 
  repetido_primer_y_segundo= False

if segundo_numero == tercer_numero:
  repetido_segundo_y_tercero=True
else:
  repetido_segundo_y_tercero= False

if tercer_numero == primer_numero:
 repetido_tercer_y_primer=True
else:
 repetido_tercer_y_primer= False

#Se hace la prueba con las constantes (if y else) para ver cual es el numero mayor del los valores ingresados
if segundo_numero<=primer_numero and tercer_numero <=primer_numero:
 numero_mayor = primer_numero + numero_mayor
elif primer_numero<=segundo_numero and    tercer_numero<=segundo_numero:
  numero_mayor = segundo_numero+numero_mayor
elif primer_numero<=tercer_numero and segundo_numero<=tercer_numero:
  numero_mayor = numero_mayor + tercer_numero


#Se hace la prueba con las constantes (if y else) para ver cual es el numero menor del los valores ingresados
if primer_numero<=segundo_numero and primer_numero   <=tercer_numero:
  numero_menor = numero_menor + primer_numero
elif segundo_numero<=primer_numero and    segundo_numero<=tercer_numero:
  numero_menor = numero_menor + segundo_numero
elif tercer_numero<=primer_numero and   tercer_numero<=segundo_numero:
  numero_menor = numero_menor + tercer_numero


#Se imprime cual es el numero mayor y el menor en los valores ingresados segun los resultados de las pruebas anteriores
print("\nEl numero mayor ingresado es = ", numero_mayor)
print("\nEl numero menor ingresado es = ",numero_menor)

#Se imprime si hay algun numero repetido en los valores ingresados segun los resultados de la prueba anterior
if repetido_primer_y_segundo == True:
 print("\nNumero repetido = ", primer_numero)
elif repetido_segundo_y_tercero == True:
 print("\nNumero repetido = ", segundo_numero)
elif repetido_tercer_y_primer == True:
  print("\nNumero repetido = ", primer_numero)
else:
  print("\nNumero repetido = ")

#Se realiza una division entera de el numero mayor entre el numero menor con un (try-except) en el caso de division entre cero
try:
 division_entera = numero_mayor//numero_menor
 print("\nEl resultado de la division entera es = ", division_entera)
except ZeroDivisionError:
  print("\nLa division entre cero no es permitida")