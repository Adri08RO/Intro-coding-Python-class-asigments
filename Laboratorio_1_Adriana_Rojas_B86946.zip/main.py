#Hola mundo 
print("¡Hola Mundo!\n")

#Imput de nombre de usuario
nombre_usuario= input("Ingrese su nombre: ")

#print nombre usuario
print("\nBienvenido:",nombre_usuario)

#variables y tipos de variables

primera_variable = 8 
print("\nPrimera variable =",primera_variable)
print("\nTipo de variable de primera variable")
print(type(primera_variable))
#primera variable es int

segunda_variable = 9.5 
print("\nSegunda variable =",segunda_variable)
print("\nTipo de variable de segunda variable")
print(type(segunda_variable))
#segunda variable es float

tercera_variable = "Ana" 
print("\nTercera variable =",tercera_variable)
print("\nTipo de variable de tercera variable")
print(type(tercera_variable))
#tercera variable es str

#Operaciones aritméticas
print("Operaciones aritméticas")
#suma
print("\nSuma de primera variable y segunda variable")
suma = primera_variable + segunda_variable
print(suma)
print("\nTipo de variable de suma de primera y segunda variable")
print(type(suma))

#resta
print("\nResta de segunda variable y primera variable")
resta = segunda_variable - primera_variable
print(resta)
print("\nTipo de variable de resta de segunda y primera variable")
print(type(resta))

#división
a = 20
b = 5
print("\nLa variable a =",a)
print("\nLa variable b =",b)

#print("\nDivisión de a entre b")
division = a/b
print("\nDivision de a entre b")
print(division)
print("\nTipo de variable de división de a entre b")
print(type(division))

#multiplicación
print("\nMultiplicación de a por b")
multiplicacion = a*b
print(multiplicacion)
print("\nTipo de variable de multiplicación de a por b")
print(type(multiplicacion))



