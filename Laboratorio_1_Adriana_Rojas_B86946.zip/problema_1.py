#Problema 1. Problema deposito y intereses ganados
print("\nProblema 1. Problema deposito y intereses ganados")

# Calcular el 20% ganado

#algoritmo calcular_intereses_ganados

#algoritmo calcular_intereses_ganados

#constantes

intereses = 0.2
MENSAJE_INTERESES = "\nLos intereses ganados son: "
MENSAJE_CANT_FINAL = "\nSu monto final es: "

#Variables

cantidad_depositada = 0
cantidad_con_intereses = 0
calculo_de_intereses = 0

#inicio

cantidad_depositada = input("Ingrese la cantidad depositada: ")
calculo_de_intereses = int(cantidad_depositada) * intereses
cantidad_con_intereses = int(cantidad_depositada) + calculo_de_intereses
print(MENSAJE_INTERESES, calculo_de_intereses)
print(MENSAJE_CANT_FINAL, cantidad_con_intereses)

#fin