#Problema 2. Problema para calcular el área y circunferencia de un circulo
print("\nProblema 1. Problema para calcular el área y circunferencia de un circulo")
import math


#Constantes
MENSAJE_AREA = ("\nEl área del circulo es:") 
PI = 3.141592

#Variables
radio = input("\nIngrese el radio del circulo: ")
radio_2 = int(radio)
print("\nEl radio ingresado es: ", radio_2)
radio_elevado_al_cuadrado = radio_2**2
area = PI*radio_elevado_al_cuadrado
circunferencia = 2*PI*radio_2

print(MENSAJE_AREA,area)
print("\nLa circunferencia del circulo es: ",circunferencia)