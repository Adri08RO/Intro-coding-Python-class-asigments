print("\nProblema 1")
print("\nBienvenido al juego de las tres reglas")
#Primero definimos el nombre del primer jugador
jugador_1= input("\nIngrese el nombre del primer jugador: ")

mensaje_0_1 ="\n{}, ingrese un numero entre 1 y 100: ".format(jugador_1)
try:
  #usamos un try-error para que los numeros ingresados solo sean enteros y un input para guardar el valor como una variable
 numero_jugador_1 = int(input(mensaje_0_1))
except ValueError:
  print("\nEl numero ingresado no es valido")

#De igual forma definimos el segundo jugador y los mismos valores necesarios para continuar el juego
jugador_2= input("\nIngrese el nombre del primer jugador: ")

mensaje_0_2= "\n{}, ingrese un numero entre 1 y 100: ".format(jugador_2)
try: 
 numero_jugador_2 = int(input(mensaje_0_2))
except ValueError:
  print("\nEl numero ingresado no es valido")

#se definen las variables de puntajes de jugadores y con ello se utilizan los condicionales if, else , elif para cumplir las reglas y que segun estas se otorgue el correspondiente puntaje a cada uno de los jugadores
puntaje_jugador_1 = 0
puntaje_jugador_2 = 0

if 60<=numero_jugador_1<=79:
  puntaje_jugador_1 += 50
elif numero_jugador_1 % 3==0:
  puntaje_jugador_1 += 30
elif numero_jugador_1 == 11:
  puntaje_jugador_1 += 20
else:
  puntaje_jugador_1 += 0

if 60<=numero_jugador_2<=79:
  puntaje_jugador_2 += 50
elif numero_jugador_2 % 3==0:
  puntaje_jugador_2 += 30
elif numero_jugador_2 == 11:
  puntaje_jugador_2 += 20
else:
  puntaje_jugador_2 += 0

#Se muestran los resultados de puntaje de cada jugador y segun las reglas cual es el ganador o si hay un empate
print("\nResultados:")
mensaje_1 = " {} - {} puntos".format(jugador_1,puntaje_jugador_1)
print(mensaje_1)
mensaje_2 = "{} - {} puntos".format(jugador_2,puntaje_jugador_2)
print(mensaje_2)
mensaje_3="¡Gana {}!".format(jugador_1)
mensaje_4="¡Gana {}!".format(jugador_2)

if puntaje_jugador_1<puntaje_jugador_2:

  print(mensaje_3)
elif puntaje_jugador_2<puntaje_jugador_1:
  print(mensaje_4)
else:
  print("¡Hay un empate!")


#Problema 2
print("\nProblema 2")

#Declaro la variable que va a almacenar el valor del usuario
#La variable a almacenar no puede ser 0 o un multiplo de 5 por que de otra forma no se ejcutaria el programa
valor_ingresado = 1
#En el momento que valor_ingresado es multiplo de 5 o cero ya no se cumple la condición de desigualdad y termina el programa
while   valor_ingresado %5 !=0 : #mientras no sea 5
 #se pide un valor
 valor_ingresado = int(input("\nIngrese un valor entero: "))
 #Se hace un condicional para que cada vez que el valor ingresado no sea multiplo de 5 aparezca el siguiente mensaje
 if valor_ingresado %5 !=0:
   print("\nEl numero no es multiplo de 5")


