#Programa para analisis de compra de materiales 

#Primero definimos los métodos

#Metodo de verificacion de resultado de la muestra
def verificar_calidad_de_muestra(nivel_de_calidad):
  resultado = ""

  #Para la aprovación de la muestra se ocupa un resultado mayor o igual a 85 y menor a 100 (utilizamos un if)

  if nivel_de_calidad >= 85 and nivel_de_calidad <= 100:
    resultado = "Aprovada"

  #Cuando la muestra se encuentra entre 70 y 84 su resultado sera se requiere otra prueba(utilizamos un elif)
 
  elif nivel_de_calidad >= 70 and nivel_de_calidad <= 84:
    resultado = "Se requiere otra prueba"

 #Cuando la muestra sea menos de 70 el resultado sera se rechaza la muestra(usamos de nuevo otro elif)

  elif nivel_de_calidad >= 1 and nivel_de_calidad <= 70:
    resultado = "Rechazada"
 #cada uno de los if o elif utilizados nos van a devolver uno de los siguientes resultados: Aprovada, Se requiere otra prueba o Rechazada y con el return devolvemos este resultados
  return resultado


#Para el segundo metodo se utilizan los resultados del metodo anterior para verificar si dependiendo de estos se compra o no el material
def verificar_compra_de_material(muestra_1,muestra_2,muestra_3):
  #Se realiza la verificacion de calidad de muestra de las 3 muestras
   resultado_de_compra = ""
   resultado_muestra_1 = verificar_calidad_de_muestra(muestra_1)

   resultado_muestra_2 = verificar_calidad_de_muestra(muestra_2)

   resultado_muestra_3 = verificar_calidad_de_muestra(muestra_3)
 #El metodo presenta dos resultados: Comprar el material o No comprar el material.
 #Para que se apruebe comprar el material dos de las muestras tienen que haber sido aprovadas del metodo anterior para cual usamos un if y dos elif para las 3 combinaciones de 2 muestras aprovadas.

 #y usamos un else para cualquier otra cosa que no sea las combinaciones que se pueden aprovar

 #Cuando 1 y 2 se aprueban
   if resultado_muestra_1 == "Aprovada" and resultado_muestra_2 == "Aprovada":
     resultado_de_compra = "Comprar el material"

 #Cuando 1 y 3 se aprueban
   elif resultado_muestra_1 == "Aprovada" and resultado_muestra_3 == "Aprovada":
     resultado_de_compra = "Comprar el material"

 #Cuando 2 y 3 se aprueban
   elif resultado_muestra_2 == "Aprovada" and resultado_muestra_3 == "Aprovada":
     resultado_de_compra = "Comprar el material"

   else:
     resultado_de_compra = "No comprar el material"
    #Por ultimo se devuelve uno de los dos resultados anteriores
   return resultado_de_compra


  


#Programa principal

#Para esta parte se verifica las muestras dadas en la primera parte y se imprime los resultados de estos

print("\nPrograma para análisis de compra de materiales")
#Se utiliza un try- except para el caso en que se ingrese un valor que no sea de tipo float para cualquiera de las 3 variables de tipo float que se ingresan(muestras) 
try:
 muestra_1 = float(input("\nIngrese el nivel de calidad de la primera muestra: "))

 #Se utiliza un if para determinar si la muestra 1 ingresada se encuentra entre 1 y 100 de lo contrario no se puede ingresar la muestra 2 y se muestra el mensaje (El valor ingresado debe encontrarse entre 1 y 100)
 if muestra_1 >= 1 and muestra_1 <=100:
   #Una vez el valor de la muestra 1 se encuentra en el rango deseado se solicita la muestra 2
   muestra_2 = float(input("\nIngrese el nivel de calidad de la segunda muestra: "))
    # Sin embargo de igual forma que para la muestra_1 sin no se encuentra en el rango se mostrara el mensaje y no procedera a pedir la muestra 3
   if muestra_2 >= 1 and muestra_2 <=100:
     #Luego se procede a pedir la muestra 3 la cual igual se valora para ver si cumple con el rango y si no se frena el programa
     muestra_3 = float(input("\nIngrese nivel de calidad de la tercera muestra: "))
     
     if muestra_3 >= 1 and muestra_3 <=100:
       print("\n>Detalle de análisis<")
       #Si el rango de la muestra 3 se cumple se procede con la verificacion de si las muestras son aprovadas, rechhazadas o requieren otra prueba esto llamando al metodo y usandolo para la verificación
       verificacion = verificar_calidad_de_muestra(muestra_1)
        #Se imprimen los resultados de las muestras y se verifican 
       print("\nPrimera muestra:", verificacion)

       verificacion = verificar_calidad_de_muestra(muestra_2)

       print("\nSegunda muestra:", verificacion)

       verificacion = verificar_calidad_de_muestra(muestra_3)

       print("\nTercera muestra:", verificacion)

       #Programa para analisis de compra de materiales
       #Se llama al segundo metodo y se aplica para las 3 muestras y se verifica si se compra el material o no
       verificar = verificar_compra_de_material(muestra_1, muestra_2, muestra_3)
       #Y se imprime el resultado del segundo metodo
       print("\nRecomendación final: ", verificar)
       #Los else son los que se utilizaron con los if para verificar el rango de cada una de las tres muestras
     else:
       print("El valor ingresado debe encontrarse entre 1 y 100")
   else:
     print("El valor ingresado debe encontrarse entre 1 y 100")
 else:
   print("El valor ingresado debe encontrarse entre 1 y 100")
except ValueError:
 print("El valor ingresado no es válido")


