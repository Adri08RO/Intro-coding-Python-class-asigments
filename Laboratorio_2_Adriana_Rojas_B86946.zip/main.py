#Problema 1. Definición de las variables
print("\nProblema 1. Definición de las variables")
print("\nVariables")
#variable 1
primer_valor = 2
print("\nprimer_valor = ",primer_valor)
#variable 2
segundo_valor = 3.3
print("\nsegundo_valor = ",segundo_valor)
#variable 3 
tercer_valor = "Costa Rica"
print("\ntercer_valor = ",tercer_valor)
#variable 4
cuarto_valor = False
print("\ncuarto_valor = ",cuarto_valor)

#Tipos de variables
tipo_1 = type(primer_valor)
tipo_2 = type(segundo_valor)
tipo_3 = type(tercer_valor)
tipo_4 = type(cuarto_valor)

#Primer programa (para leer el tipo de variable)

#Mensajes
#mensaje para el tipo de la primera variable
mensaje_primer_valor = "\nEl tipo de la variable \ \"primer_valor\" \ es:\n"
#mensaje para el tipo de la segunda variable
mensaje_segundo_valor = "\nEl tipo de la variable \ \"segundo_valor\" \ es:\n"
#mensaje para el tipo de la tercera variable
mensaje_tercer_valor = "\nEl tipo de la variable \ \"tercer_valor\" \ es:\n"
#mensaje para el tipo de la tercera variable
mensaje_cuarto_valor = "\nEl tipo de la variable \ \"cuarto_valor\" \ es:\n"
#Resultado de la clasificacion de tipos de variables
print(mensaje_primer_valor,tipo_1)
print(mensaje_segundo_valor,tipo_2)
print(mensaje_tercer_valor,tipo_3)
print(mensaje_cuarto_valor,tipo_4)

#Problema 2. Programa para determinar si un número es par ó impar
print("\nProblema 2. Programa para determinar si un número es par ó impar") 

#valor a verificar

valor_1 = int(input("\nDigite el número a verificar: "))

#Se utiliza el modulo 2 y residuo para verificar que el numero es par o impar

mod = valor_1 % 2

#Se utiliza utiliza el modulo 2 y residuo para verificar que el numero es par o impar
if mod > 0:
 print("\nEl número ingresado (",valor_1,") es impar")

else:
   print("\nEl número ingresado (",valor_1,") es par")
