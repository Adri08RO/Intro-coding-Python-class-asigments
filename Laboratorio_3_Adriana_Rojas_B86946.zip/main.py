#Problema 2
print("\nProblema 2")

#Entrada al programa
print("\n¡Bienvenid@ al programa de cálculo de notas!")

#Se utiliza input para definir la variable nombre de usuario
nombre_usuario= input("\nIngrese el nombre del estudiante: ")

#Se definen tres variables para las notas de los examenes con input y se restrigen los valores permitidos a numeros enteros o string con int
nota_1= int(input("\nIngrese la nota del primer examen: "))
nota_2= int(input("\nIngrese la nota del segundo examen: "))
nota_3= int(input("\nIngrese la nota del tercer examen: "))

#Se obtiene los valores porcentuales de las variables de notas al multiplicar estas por el porcentaje dado de valor para cada examen
nota_1_porcentual = nota_1*0.25
nota_2_porcentual = nota_2*0.35
nota_3_porcentual = nota_3*0.40

#Despues de realizar el paso anterior solo es necesario sumar las notas porcentuales para encontrar el promedio de notas
promedio_de_notas = (nota_1_porcentual+nota_2_porcentual+nota_3_porcentual)

#Se imprime el promedio ponderado junto con el nombre del alumno al que pertenece  
print("\nLa nota final de "+nombre_usuario+" es: ",promedio_de_notas)

#Se utiliza los condicionales if y else para separar las notas aprobadas de las reprobadas
if promedio_de_notas>=70:
  estado = "APROBADO"
else:
   estado = "REPROBADO"

#Por ultimo se imprime el estado del estudiante ya sea APROBADO o REPROBADO
print("\nEl estado es: ", estado)