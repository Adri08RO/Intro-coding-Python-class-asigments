#Primer problema
print("\nProblema 1")
#este primer problema es un programa de vector de nombres
print("\nPROGRAMA DE VECTOR DE NOMBRES")
#primero creamos un vector llamado cantidad_de_nombres
cantidad_de_nombres= int(input("\nIndique la cantidad de nombres que desea ingresar: "))

#de igual forma forma creamos un vector vacio llamado vector_nombres
vector_nombres = []

#por medio de for cremos un programa en el cual por el rango de cantidad de nombres imprima ese numero de veces un input nombres el cual se va a guardar en nuestro vector_nombres
for contador in range(cantidad_de_nombres):
 nombres = input("\nIndique el nombre a ingresar: ")
 vector_nombres.append(nombres)

#pasamos el vector_nombres a lista e str y lo imprimimos 
list(vector_nombres)
print("\nLa lista original es:" + str(vector_nombres))

#para imprimir el vector inverso 
vector_inverso = vector_nombres[::-1]
print("\nLa lista inversa es: " +str(vector_inverso))
#Problema 2
print("\nProblema 2")
#programa de frecuencia de valores
print("\nPROGRAMA DE FRECUENCIAS DE VALORES")

#creamos una variable booleana
continuar = True
#y creamos un while con la anterior variable
while continuar == True:
 repeticiones = int(input("\nIndique la cantidad de números que desea generar (entre 10 y 50): "))
 #tambien se pone una restriccion con un if para que los valores ingresados solo se puedan encontrar entre 10 y 50 y de no ser asi que imprima un mensaje de error y vuelva a pregutar
 if repeticiones>=10 and repeticiones<=50:
   continuar = False
 else:
   print("\nEl valor ingresado no es válido")
   continuar = True


#creamos 3 vectores vacios vector_valores, vector_frecuencias y vector_frecuencias_2
vector_valores = []
vector_frecuencias = []
vector_frecuencias_2 = []

#se imprime resultados
print("\n--Resultados--")
#y se deja un espacio
print("\n")
#luego se utiliza un for para generar igual numero de numeros que en repeticiones y que estos numeros generados se encuentren en el rango entre 1 y 20 y se anexen al vector_valores
for contador in range (repeticiones):
 import random
 valores = random.randint(1,20)
 vector_valores.append(valores)

#se utiliza una variable para definir largo del vector valores
largo_vector =len(vector_valores)
#se define el indice
indice = 0 

#se define un metodo mediante el cual se encuentra la frecuencia que un numero se repite en vector valores y que este numero se agregue a vector frecuencias usando un for 
def encontrar_frecuencia(vector_valores, largo_vector):

  for elemento in range(largo_vector):
    vector_frecuencias.append(vector_valores.count(vector_valores))

  for elemento in range(largo_vector):
    if elemento in vector_frecuencias == 1:
     elemento[indice]+=1
    elif elemento in vector_frecuencia == 2:
      elemento[indice]+=1
    elif elemento in vector_frecuencia == n+1:
       elemento[indice]+=1

   
#se define el metodo para quitar los valores repetidos de vector_valores, esto utilizando while, if, elif, y for 
def quitar_valores_repetidos(vector_valores):
 repetido = True
 while repetido == True:
   if elemento[indice] > 1:
     for elemento in vector_valores:
       del vector_valores[elemento]
  
   elif elemento[indice] == 1:
     for elemento in vector_valores:
       set(elemento) in vector_valores
       repetido = False

#por ultimo imprimimos el resultado
for contador in range (vector_frecuencias):
  print("Número: ", vector_valores + "Frecuencia:" + vector_frecuencias )

  

  


