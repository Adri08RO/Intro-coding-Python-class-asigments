print("\nProblema 1")

#primero usamos una variable booleana para hacer el while

continuar = True

while continuar == True:
  #Tambien usamos un try-except para que el programa solo pueda recibir solo numeros enteros 

 try:
   numero_base = int(input("\nIngrese un numero entero entre 1 y 100: "))
 except ValueError:

   #En el caso de que el numero no sea entero se imprime un texto que diga que no es entero

   print("\nEl numero ingresado no es entero")
   continuar = True
 
 #Despues se prueba si el numero ingresado se encuentra entre 0 y 100 con un if, si se encuentra se prosigue con el programa y se muestra un mensaje que debe ser mayor a cero y menor a 100 y vuelve apreguntar por otro numero hasta que el numero ingresado se encuentre en este intervalo
 
 if 0<numero_base and numero_base<100:
   continuar = False
 else:
   print("\nEl numero no es valido por que debe ser mayor a 0 y menor a 100")
   continuar =True

print("\nResultado")

#Se imprime el resultado y con todos los numeros pares en el intervalo de 1 a el numero ingresado(haciendo una prueba con for y if para ver que numeros pares en el intervalo)

for elemento in range(1,numero_base+1):
  if elemento % 2 ==0:
   print(elemento)

print("\nProblema 2")

#primero se ingresa un numero 

numero_factorial= int(input("\nIngrese un número: "))

#para sacar el factorial de este numero utilizamos un for con el cual se recorre todos los numeros en el rango de 1 a el numero ingresado y multiplicando cada uno de los numeros en este rango 

for contador in range(1, numero_factorial):
 numero_factorial = numero_factorial*contador
   
print("\nEl factorial es: " , numero_factorial)


print("\nProblema 3")

print("\nPrograma para el calculo de factorial")

#Es parecido ala ejercicio anterior solo que aqui utilizamos de nuevo una variable booleana para definir un while 

continuar_1 = True

while continuar_1 == True:
 
  numero_factorial= int(input("\nIngrese un número: "))
  
  for contador in range(1, numero_factorial):
   numero_factorial = numero_factorial*contador
   
  print("\nEl factorial es: " , numero_factorial)
 
 #Se realiza una pregunta 
 
  pregunta = int(input("\n¿Desea ingresar otro numero?(1-SI/ 2-NO): "))
 
 #Y dependiendo de la respuesta se vuelve a repetir el programa de determinar el factorial(utilizando if-else) hasta que ya no se quiera ingresar otro numero en este caso se imprime gracias por utilizar el Programa
 
  if pregunta == 1:
   continuar_1= True
  elif pregunta ==2:
   print("\nGracias por utilizar el programa")
   continuar_1 = False


print("\nProblema 4")

#De nuevo definimos una variable para utilizar un whilw para que en el caso de que el numero no se encuentre en el rango necesario se muestre una advertensia y se vuelva a ingresar otra vez

continuar_2 = True

while continuar_2 == True:

  #Tambien se utiliza el try para que solo sea posible ingresar numeros enteros

 try:
   numero_base = int(input("\nIngrese un numero entero entre 1 y 100: "))
 except ValueError:
   print("\nEl numero ingresado no es entero")
   continuar_2 = True

 if 0<numero_base and numero_base<100:
   continuar_2 = False
 else:
   print("\nEl numero no es valido por que debe ser mayor a 0 y menor a 100")
   continuar_2 =True


#En este caso para asegurarnos que los elementos pares en el rango se impriman de forma horizontal se crea una lista 

lista_pares_enteros = [ ]

#Con ayuda del for todos los elementos pares en el rango se agregan a la lista usando el comando append

for elemento in range(1,numero_base+1):
  if elemento % 2 ==0:
   lista_pares_enteros.append(elemento)
   
#Por ultimo con la ayuda de stackoverflow el siguiente comando ayuda a separar los elementos en la lista e imprimirlos 

print("\nResultado: ", *lista_pares_enteros, sep=", " )

