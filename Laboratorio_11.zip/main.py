#Problema 1
#Una forma en la cual se pueden utilizar las matrices para la resolocion de un problema es para la organización y manipulacion de datos en forma de tablas lo cual es algo necesario para ordenar datos por medio de columnas y de filas y segun el caso realizar calculos entre las filas y columnas necesarias para optener algun tipo de resultado

print("\nProblema 2")
#Para este segundo problema primero definimos el vector de cursos
vector_cursos = []

#Despues definimos la clase estudiante_1 en la cual definimos a su vez a las cualidades nombre y vector de cursos
class Estudiante_1:
 def __init__ (self, nombre):
   self.nombre = nombre
   self.vector_cursos = []

 #de igual forma definimos el metodo get nombre para obtener el nombre de la clase estudiante_1
 def get_nombre(self):
   return self.nombre

 #tambien definimos el metodo get vector cursos para regresar todos los cursos que se agreguen a la clase
 def get_vector_cursos(self): 
   return self.vector_cursos
 
 #y mediante el metodo agregar cursos agregamos los cursos que queramos 
 def agregar_curso(self, curso):
   self.vector_cursos.append(curso)

   
   
#Programa principal
#primero agregamos el nombre de la clase por medio de un input
nombre = input("\nDigite el nombre del estudiante: ")
estudiante = Estudiante_1(nombre)

#creamos una variable booleana para usar junto con un while 
continuar_1 = True

#el while que usaremos a continuación se usara para en caso de que se desee agregar otro curso mediante la pregunta y los if y elif pueda continuar agreagar otro curso o salir del programa
while continuar_1:
 curso = input("\nIngrese el nombre del curso: ")
 estudiante.agregar_curso(curso)

 pregunta = int(input("\n¿Desea ingresar otro curso? (1-Sí, 2-No): "))
 if pregunta == 1:
   continuar = True
 elif pregunta == 2:
   print("\nEstudiante: ", estudiante.get_nombre())
   print("\nCursos: ", estudiante.get_vector_cursos())
   print("\n\nGracias por utilizar el programa")
   continuar = False
   break


print("\n\nProblema 3")

#para el tercer problema primero definimos la clase estudiante 2 en la cual sus caracteristicas seran el nombre el vector cursos y el vector notas

class Estudiante_2:
  def __init__ (self, nombre):
   self.nombre = nombre
   self.vector_cursos = []
   self.vector_notas = []
   
 #tambien definimos los metodos de nombre para regresar el nombre de la clase
  def get_nombre(self):
    return self.nombre

 #metodo get vector notas para regresar las notas de los cursos agregados
  def get_vector_notas(self):
   return self.vector_notas

 #metodo get vector cursos para obtener de regreso los cursos introducidos
  def get_vector_cursos(self): 
   return self.vector_cursos

 #metodo agregar cuso para agregar cursos 
  def agregar_curso(self, curso):
    self.vector_cursos.append(curso)
 #y metodo agregar notas para agregar notas de los cursos
  def agregar_nota(self, nota):
    self.vector_notas.append(nota)



#Programa principal
#primero agregamos el nombre a la clase estudiante 2 mediante un input
nombre = input("\nDigite el nombre del estudiante: ")
estudiante = Estudiante_2(nombre)

#definimos una variable booleana para usar despues con el while
continuar = True

#usamos while, if y elif para definir que cuando la pregunta se responda que no el programa se detenga e imprima los cursos y notas pero si se responde que si siga preguntando por otro curso y su respectiva nota 
while continuar:
  curso = input("\nIngrese el nombre del curso: ")
  estudiante.agregar_curso(curso)

  nota = input("\nIngrese la nota: ")
  estudiante.agregar_nota(nota)

  pregunta = int(input("\n¿Desea ingresar otro curso? (1-Sí, 2-No): "))
  if pregunta == 1:
   continuar = True
  elif pregunta == 2:
    continuar = False
    print("\nEstudiante: ", estudiante.get_nombre())
    for contador in range(len(estudiante.vector_cursos)):  
       print("\nCursos")
       linea_imprimir = "\n" + str(estudiante.vector_cursos[contador]) + ", nota: " + str(estudiante.vector_notas[contador])
       print(linea_imprimir)
       print("\n\nGracias por utilizar el programa")
       